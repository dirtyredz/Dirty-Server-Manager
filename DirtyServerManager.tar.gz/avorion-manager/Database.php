<?php

$Login=array (
  'ADMIN' => 
  array (
    'Hash' => '$2y$10$QZcqcDT/jUbL.turyuyo8u6n8gCvOfJqjT31/fs3fb59GSr9ja862',
    'Role' => '100',
  ),
  'DARKPAAPI' => 
  array (
    'Hash' => '$2y$10$snoXxzVKpwiBhtWZ8Bwl4OrSp.zeFwA5VR7uk17rkAO2jyFYwlaPi',
    'Role' => '10',
  ),
  'DIRTYREDZ' => 
  array (
    'Hash' => '$2y$10$371un4hl5r1UHo4tPMvfqeXerU8ow6WvgNIxbDkLslNSue565ThZ2',
    'Role' => '50',
  ),
);