<?php
$Login=array (
  'ADMIN' =>
  array (
    'Hash' => '$2y$10$MoNHGw.CAeDClZfttf5ykutDh1wws/M82EAz704lSYqqrfDe6GTCu',
    'Role' => '100',
  ),
);
